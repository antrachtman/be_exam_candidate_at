/*
 * Main is really bloated, but I ran out of time to really separate it out into more classes and clean it up.
 * This program on startup will create directories as required. 
 * The program requires an input, output and error directory. It also requires a data directory, but that is hardcoded and should not change.
 * The function is to watch the input forlder for .csv files. The program will convert them to .json files.
 * It is assumed that any files in input are .csv files. All other types will be deleted.
 * The csv files are assumed to have headers as well. The output folder will take in the resulting .json file.
 * The error folder holds logs of any errors that were discovered during conversion.
 * The error log retains the .csv extension because it keeps the same name as the file it was reading.
 * The data folder contains a data.txt file which contains all of the file names that were previously used for comparison.
 */
package seedexam;

import java.io.*;
import java.nio.file.*;
import static java.nio.file.LinkOption.NOFOLLOW_LINKS;
import static java.nio.file.StandardWatchEventKinds.ENTRY_CREATE;
import static java.nio.file.StandardWatchEventKinds.OVERFLOW;
import java.nio.file.WatchEvent.Kind;
import java.util.*;

/**
 *
 * @author Andrew Trachtman
 */
public class SeedExam {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Hardcode data directory to wherever the program is
        File dataDir = new File("./data");
        dataDir.mkdir();
        File dataFile = new File(dataDir + "/directories.txt");
        //If the data file for the directories already exists, do nothing. Otherwise create the directory and set up defaults.
        try{
            if(dataFile.createNewFile()){
                FileWriter fw = new FileWriter(dataFile);
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write("./inputs");
                bw.newLine();
                bw.flush();
                bw.write("./outputs");
                bw.newLine();
                bw.flush();
                bw.write("./errors");
                bw.newLine();
                bw.flush();
            }
        } catch (IOException e) {System.out.println(e);}
        //Go to where the hardcoded data file is and use the information in it or the handler will assign defaults.
        DirectoryReader dr = new DirectoryReader(dataFile);
        FileHandler handler = new FileHandler(dr.getInput(), dr.getOutput(), dr.getError());
        
        File data = new File(handler.getDataDir() + "/data.txt");
        
        UsedNamesList namesHandler = new UsedNamesList(dr.getInput(), dr.getOutput(), dr.getError());
        
        csvFilter csv = new csvFilter(handler);
        
        ArrayList<String> names;
        names = namesHandler.getNamesList();
        namesHandler.loadNames(data);
        
        //Create a watcher to monitor the input directory.
        Path directory = handler.inputFile.toPath();
        
        try{
            Boolean isDirectory = (Boolean) Files.getAttribute(directory, "basic:isDirectory", NOFOLLOW_LINKS);
            if(!isDirectory){
                throw new IllegalArgumentException("User path " + directory + " does not point to a valid folder.");
            }
        }catch (IOException e){System.out.println(e);}
        try{
            WatchService watcher = FileSystems.getDefault().newWatchService();
            directory.register(watcher, StandardWatchEventKinds.ENTRY_CREATE);
            
            while(true){
                //Make a watcher using the nio watch event since it's much more efficient than a workaround or a from scratch approach
                WatchKey key = watcher.take();
                Kind<?> kind = null;
                for(WatchEvent<?> eventWatcher : key.pollEvents()){
                    kind = eventWatcher.kind();
                    //If things process too fast, just continue.
                    if(kind == OVERFLOW){
                        continue;
                    }
                    //If new file is added to input process it only if it is a .csv
                    else if(kind == ENTRY_CREATE){
                        Path newPath = ((WatchEvent<Path>) eventWatcher).context();
                        String extension = handler.checkFileExtension(newPath.toString());
                        if(extension.equals("csv")){
                            namesHandler.writeToData(newPath);
                            System.out.println("New csv file discovered: " + newPath);
                            csv.processFile(newPath.toFile());
                        }else{
                            //Deletes any files that aren't .csv files.
                            System.out.println("File type " + extension + " is not accepted. Please use a .csv");
                            try{
                                Path tempPath = Paths.get(handler.getInputPath(), newPath.toString());
                                tempPath.toFile().delete();
                                System.out.println("Deleted " + tempPath);
                            } catch (Exception e) {System.out.println(e);}
                        }
                    }
                    if(!key.reset()){
                        break;
                    }
                }
            }
        } catch (IOException e){System.out.println(e);}
        catch(InterruptedException ie){System.out.println(ie);}
    }
}
