/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seedexam;
import java.io.*;
import org.apache.commons.io.FilenameUtils;

/**
 *
 * @author Andrew Trachtman
 */
public class FileHandler {
    //Holds the paths to use for logging input, output and error logs
    String inputPath = "";
    String outputPath = "";
    String errorPath = "";
    String dataPath = "";
    
    //Holds the files that will make the directories
    File inputFile = null;
    File outputFile = null;
    File errorFile = null;
    File dataFile = null;
    
    //Constructor for FileReader - Takes in the directory file paths to use - Expected to only need 1 configuration, hence exclusion of get/set
    public FileHandler(String input, String output, String error){
        inputPath = input;
        outputPath = output;
        errorPath = error;
        
        //Hardcoded
        dataPath = "./data";
        
        //Set the files based on the paths determined.
        inputFile = new File(inputPath);
        outputFile = new File(outputPath);
        errorFile = new File(errorPath);
        dataFile = new File(dataPath);
        
        //Generate the directories to hold and store the logs.
        inputFile.mkdir();
        outputFile.mkdir();
        errorFile.mkdir();
        dataFile.mkdir();
    }
    
    //Getters
    public String getInputPath(){
        return inputPath;
    }
    
    public String getOutputPath(){
        return outputPath;
    }
    
    public String getErrorPath(){
        return errorPath;
    }
    
    public String getDataPath(){
        return dataPath;
    }
    
    public File getInputDir(){
        return inputFile;
    }
    
    public File getOutputDir(){
        return outputFile;
    }
    
    public File getErrorDir(){
        return errorFile;
    }
    
    public File getDataDir(){
        return dataFile;
    }
    
    //Setters - Likely not needed in this case due to the assumption that we won't be changing the directories.
    
    //It made more sense to use a library for this functionality.
    public String checkFileExtension(String filePath){
        return FilenameUtils.getExtension(filePath);
    }
}
