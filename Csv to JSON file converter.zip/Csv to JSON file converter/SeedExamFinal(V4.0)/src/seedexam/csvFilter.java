/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seedexam;

import java.io.*;
import java.nio.file.*;
import java.util.regex.*;

/**
 *
 * @author Andrew Trachtman
 */
public class csvFilter {

    Path inputPath;
    Path outputPath;
    Path errorPath;
    FileHandler handler;

    //Constructor - Set where to pull from, save to and report errors.
    public csvFilter(FileHandler fHandler) {
        //Process the paths held by the handler provided.
        Path filePath = fHandler.getInputDir().toPath();
        Path filePath2 = fHandler.getOutputDir().toPath();
        Path filePath3 = fHandler.getErrorDir().toPath();

        inputPath = filePath;
        outputPath = filePath2;
        errorPath = filePath3;

        //Set the handler to reference for this csvFilter
        handler = fHandler;
    }

    public void processFile(File data) {
        File inputData = Paths.get(handler.getInputPath(), data.toString()).toFile();
        File outputData = Paths.get(handler.getOutputPath(), data.toString()).toFile();
        File errorData = Paths.get(handler.getErrorPath(), data.toString()).toFile();
        File jsonFile = Paths.get(handler.getOutputPath(), this.convertToJSON(data).toString()).toFile();

        try {
            //Ensure that the error file exists. If not, make it.
            errorData.createNewFile();
            //Set up readers and writers
            FileReader fr = new FileReader(inputData);
            BufferedReader br = new BufferedReader(fr);
            FileWriter fw = new FileWriter(jsonFile);
            BufferedWriter bw = new BufferedWriter(fw);
            FileWriter fwError = new FileWriter(errorData);
            BufferedWriter bwError = new BufferedWriter(fwError);

            //Temporary and transfer variables used to hold data during manipulation
            String tempStr;
            String[] transArray;
            int currentLine = 1;

            //Skip the first line because we've been promised a header.
            br.readLine();
            //Read from the file until EOF. Load each line (which should be the name of a file only) into the tempList
            while ((tempStr = br.readLine()) != null) {
                currentLine++;
                String[] tempArray = tempStr.split(",");

                //Error checking for number of columns
                //TODO - What happens if the input looks like: "asd,asd",asd,asd,asd,asd? This will cause an error as is.
                if (tempArray.length == 5) {
                    //Middle name should be present.
                    transArray = this.processFull(tempArray);
                    this.errorOutput(transArray, currentLine, bw, bwError);
                } else if (tempArray.length == 4) {
                    //Middle name should NOT be present.
                    transArray = this.processPart(tempArray);
                    this.errorOutput(transArray, currentLine, bw, bwError);
                } else {
                    if (tempArray.length > 5) {
                        bwError.write("Error on line " + currentLine + System.getProperty("line.separator") + "There are too many data columns present.");
                        bwError.newLine();
                        bwError.flush();
                    } else {
                        bwError.write("Error on line " + currentLine + System.getProperty("line.separator") + "There are not enough data columns present.");
                        bwError.newLine();
                        bwError.flush();
                    }
                }
            }
            //Close readers and writers
            br.close();
            bw.close();
            bwError.close();
            fr.close();
            fw.close();
            fwError.close();
            
            //I normally prefer to write readers and writers more explicitly, but this is a quick one off to check if the error file is empty.
            BufferedReader brErrorCheck = new BufferedReader(new FileReader(errorData));
            if(brErrorCheck.readLine() == null){
                brErrorCheck.close();
                errorData.delete();
            }
            brErrorCheck.close();
            //Close everything and delete input file.
            inputData.delete();
            
        } catch (IOException e) {
            System.out.println(e);
        }
    }
    
    //Assumes array contains 5 elements.
    public String[] processFull(String[] array) {
        String[] output = new String[5];

        //If an error is found at any point, assign an error code to that array element.
        //+++ERROR01+++ - String is empty
        //+++ERROR02+++ - String is too long
        //+++ERROR03+++ - Phone number isn't in the right format
        //Check each element and assign error codes to the return array values if necessary
        String id = array[0];
        if (id.length() > 8) {
            id = "+++ERROR02+++";
        } else if (id.length() < 1) {
            id = "+++ERROR01+++";
        }

        String fName = array[1];
        if (fName.length() > 15) {
            fName = "+++ERROR02+++";
        } else if (fName.length() < 1) {
            fName = "+++ERROR01+++";
        }

        String mName = array[2];
        if (mName.length() > 15) {
            mName = "+++ERROR02+++";
        } else if (mName.length() < 1) {
            mName = "+++ERROR01+++";
        }

        String lName = array[3];
        if (lName.length() > 15) {
            lName = "+++ERROR02+++";
        } else if (lName.length() < 1) {
            lName = "+++ERROR01+++";
        }

        String phoneNum = array[4];

        //Match 3 digits at the start of the string, a hyphen, 3 digits, a hyphen and then 4 digits at the end specifically.
        Pattern phoneFormat = Pattern.compile("^(\\d{3}-\\d{3}-\\d{4})$");
        Matcher match = phoneFormat.matcher(phoneNum);

        if (!match.find()) {
            phoneNum = "+++ERROR03+++";
        }

        //Set the array to output
        output[0] = id;
        output[1] = fName;
        output[2] = mName;
        output[3] = lName;
        output[4] = phoneNum;

        return output;
    }

    //Assumes array contains 4 elements.
    public String[] processPart(String[] array) {
        String[] output = new String[4];

        //If an error is found at any point, assign an error code to that array element.
        //+++ERROR01+++ - String is empty
        //+++ERROR02+++ - String is too long
        //+++ERROR03+++ - Phone number isn't in the right format
        //+++ERROR04+++ - Must be all digits
        //+++ERROR05+++ - Must be all digits and less than 8 characters
        //+++ERROR06+++ - Must be all digits and more than 0 characters
        String id = array[0];

        String fName = array[1];
        if (fName.length() > 15) {
            fName = "+++ERROR02+++";
        } else if (fName.length() < 1) {
            fName = "+++ERROR01+++";
        }

        String lName = array[2];
        if (lName.length() > 15) {
            lName = "+++ERROR02+++";
        } else if (lName.length() < 1) {
            lName = "+++ERROR01+++";
        }

        String phoneNum = array[3];

        //Match 3 digits at the start of the string, a hyphen, 3 digits, a hyphen and then 4 digits at the end specifically.
        Pattern phoneFormat = Pattern.compile("^(\\d{3}-\\d{3}-\\d{4})$");
        Matcher match = phoneFormat.matcher(phoneNum);

        if (!match.find()) {
            phoneNum = "+++ERROR03+++";
        }

        //Make sure all id characters are digits
        Pattern checkDigits = Pattern.compile("^(\\d{1,8})$");
        Matcher matchDigits = checkDigits.matcher(id);

        //Check the regex to see if any errors apply to the id column.
        if (!matchDigits.find()) {
            id = "+++ERROR04+++";
            if (id.length() > 8) {
                id = "+++ERROR05+++";
            } else if (id.length() < 1) {
                id = "+++ERROR01+++";
            }
        } else if (id.length() > 8) {
            id = "+++ERROR02+++";
        } else if (id.length() < 1) {
            id = "+++ERROR01+++";
        }

        output[0] = id;
        output[1] = fName;
        output[2] = lName;
        output[3] = phoneNum;

        return output;
    }

    //Outputs to the error file specified by the writers that are input. 
    //(String[] transArray-------int currentLine----------------------------------BufferedWriter bw------------BufferedWriter bwError------boolean ignore)
    //(Array to parse info from, Current line number in the input for error logs, output writer to write with, error writer to write with, does this method check for errors or just output?)
    public void errorOutput(String[] transArray, int currentLine, BufferedWriter bw, BufferedWriter bwError) {
        String output;
        boolean containsError = false;

        for (int i = 0; i < transArray.length; i++) {
            //Error logging takes place here.
            try {
                //Check for specific error codes that are unlikely to be used as input
                if (transArray[i].equals("+++ERROR01+++")) {
                    bwError.write("Error on line " + currentLine + " data column " + (i + 1) + " -> The data element is empty");
                    bwError.newLine();
                    bwError.flush();
                    containsError = true;
                }
                if (transArray[i].equals("+++ERROR02+++")) {
                    bwError.write("Error on line " + currentLine + " data column " + (i + 1) + " -> The data element has more than 15 characters");
                    bwError.newLine();
                    bwError.flush();
                    containsError = true;
                }
                if (transArray[i].equals("+++ERROR03+++")) {
                    bwError.write("Error on line " + currentLine + " data column " + (i + 1) + " -> Phone number is not in the correct format. Correct format: ###-###-####");
                    bwError.newLine();
                    bwError.flush();
                    containsError = true;
                }
                if (transArray[i].equals("+++ERROR04+++")) {
                    bwError.write("Error on line " + currentLine + " data column " + (i + 1) + " -> The data element must only contain digits.");
                    bwError.newLine();
                    bwError.flush();
                    containsError = true;
                }
                if (transArray[i].equals("+++ERROR05+++")) {
                    bwError.write("Error on line " + currentLine + " data column " + (i + 1) + " -> The data element must only contain digits and has more than 8 characters.");
                    bwError.newLine();
                    bwError.flush();
                    containsError = true;
                }

            } catch (IOException e) {
                System.out.println(e);
            }
        }
        //We don't want to print the header or any errors as a json objects
        if (containsError == false) {
            try {
                if (transArray.length == 4) {
                    output = "{" + System.getProperty("line.separator")
                            + "id: " + transArray[0] + "," + System.getProperty("line.separator")
                            + "name: {" + System.getProperty("line.separator")
                            + "first: \"" + transArray[1] + "\"," + System.getProperty("line.separator")
                            + "last: \"" + transArray[2] + "\"," + System.getProperty("line.separator")
                            + "}," + System.getProperty("line.separator")
                            + "phone: \"" + transArray[3] + "\"" + System.getProperty("line.separator")
                            + "}";
                } else if (transArray.length == 5) {
                    output = "{" + System.getProperty("line.separator")
                            + "id: " + transArray[0] + "," + System.getProperty("line.separator")
                            + "name: {" + System.getProperty("line.separator")
                            + "first: \"" + transArray[1] + "\"," + System.getProperty("line.separator")
                            + "middle: \"" + transArray[2] + "\"," + System.getProperty("line.separator")
                            + "last: \"" + transArray[3] + "\"," + System.getProperty("line.separator")
                            + "}," + System.getProperty("line.separator")
                            + "phone: \"" + transArray[4] + "\"" + System.getProperty("line.separator")
                            + "}";
                } else {
                    output = null;
                    System.out.println("Data has an incorrect number of columns. No output written.");
                }
                if (output != null) {
                    bw.write(output);
                    bw.newLine();
                }
                bw.flush();
            } catch (IOException e) {
                System.out.println(e);
            }
        }
    }

    public File convertToJSON(File file) {
        int index = file.getName().lastIndexOf(".");
        String name = file.toString();
        name = name.substring(0, index);
        return new File(name + ".json");
    }
}
