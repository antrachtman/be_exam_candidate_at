/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seedexam;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author DakiDozer
 */
public class DirectoryReader {
    String input;
    String output;
    String error;
    
    public DirectoryReader(File file) {
        String[] temp = new String[3];
        try {
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            String str;
            int count = 0;
            
            while((str = br.readLine()) != null){
                temp[count] = str;
                count++;
            }
            input = temp[0];
            output = temp[1];
            error = temp[2];
        } catch (IOException e) {
            System.out.println(e);
        }
    }
    
    public String getInput(){
        return input;
    }
    
    public String getOutput(){
        return output;
    }
    
    public String getError(){
        return error;
    }
}
