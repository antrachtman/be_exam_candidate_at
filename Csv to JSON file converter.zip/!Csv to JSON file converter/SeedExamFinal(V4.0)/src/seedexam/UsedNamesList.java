/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seedexam;
import java.io.*;
import java.nio.file.Path;
import java.util.*;

/**
 *
 * @author Andrew Trachtman
 */
public class UsedNamesList {
    //We don't know how much stuff we're dealing with, so use a dynamic array from the util library vs a fixed one
    //TODO Reach: Increase the efficency of searches with hash tables, binary search, sorting, etc.
    
    //This array list will store the names that come into the program from the input folder. We will read from this while the program runs.
    ArrayList<String> namesList;
    //Since so many of these methods use the handler, make it in scope of all methods.
    FileHandler handler;
    
    //Constructor
    public UsedNamesList(String inputPath, String outputPath, String errorPath){
        namesList = new ArrayList<String>();
        handler = new FileHandler(inputPath, outputPath, errorPath);
    }
    
    //Add a file name to the list
    public void addName(String name){
        if(!namesList.contains(name) && namesList != null){
            namesList.add(name);
        }
        namesList.trimToSize();
    }
    
    //Check if a name exists in the namesList arraylist
    public boolean checkForName(String name){
        boolean matchFound = false;
        
        //TODO: Improve search functionality
        if(namesList.contains(name)){
            matchFound =true;
        }
        
        return matchFound;
    }
    
    //This is required to load all of the names of previously read files into an array list which will be used by main to check for changes.
    public void loadNames(File filename){
        //Output the contents to an array list
        ArrayList<String> tempList = new ArrayList<String>();
        try{
            File data = new File(handler.getDataPath() + "/data.txt");
            //Creates file if it doesn't exist.
            data.createNewFile();
            FileReader fr = new FileReader(data);
            //Buffer the inputs to process line by line
            BufferedReader br = new BufferedReader(fr);
            
            String tempStr;
            //Read from the file until EOF. Load each line (which should be the name of a file only) into the tempList
            while((tempStr = br.readLine())!=null){
                tempList.add(tempStr);
            }
            
        } catch (IOException e){System.out.println(e);}
        tempList.trimToSize();
        //Set the current array list to the temp list to check against.
        namesList = tempList;
    }
    
    //Test functionality
    public void print(){
        for(int i = 0; i < namesList.size(); i++){
            System.out.println(namesList.get(i));
        }
    }
    
    //
    public void writeToData(Path path){
        try{
            File data = new File(handler.getDataPath() + "/data.txt");
            FileWriter fw = new FileWriter(data, true);
            BufferedWriter bw = new BufferedWriter(fw);
            //Make sure the list we're about to compare to is up to date.
            this.loadNames(data);
            //Then get everything after the last separator. That should be the file name.
            if(!this.checkForName(path.toString())){
                System.out.println("WRITING");
                namesList.add(path.toString());
                bw.write(path.toString());
                bw.newLine();
            }else{
                //Don't write if we already have this file as "seen"
                System.out.println("Duplicate filename inserted. No writes made.");
            }
            bw.close();
        } catch (IOException e){System.out.println(e);}
    }
    
    public ArrayList<String> getNamesList(){
        return namesList;
    }
}
